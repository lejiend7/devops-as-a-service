
  # DevOps and Architecture Service

  This is a code bundle for DevOps and Architecture Service. The original project is available at https://www.figma.com/design/Go4m24AFFlWcnWYivope41/DevOps-and-Architecture-Service.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  